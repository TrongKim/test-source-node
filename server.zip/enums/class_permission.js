const OWNER_CLASS = 1;
const STUDENT = 0;

module.exports = {OWNER_CLASS, STUDENT};